# Excel AI Automation

This project allows you to upload an Excel file, enter a command (like "calculate net salary"), and get a processed Excel file using AI logic.

## Run locally

```
pip install -r requirements.txt
python app.py
```

## Deploy to Render

Connect your GitHub, and add this repo to Render. Make sure to use `.render.yaml` config.