import pandas as pd
from prompts import generate_prompt

def process_excel(file_path, command):
    df = pd.read_excel(file_path)
    prompt = generate_prompt(command, df.columns.tolist())
    logic = call_ai(prompt)
    try:
        exec(logic, globals())
    except Exception as e:
        print("Error in AI logic:", e)
    output_path = "processed.xlsx"
    df.to_excel(output_path, index=False)
    return output_path

def call_ai(prompt):
    # Simulated AI logic - replace with real API call
    return "df['net'] = df['salary'] - df['od'] + df['bonus']"