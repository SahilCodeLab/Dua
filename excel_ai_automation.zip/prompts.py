def generate_prompt(command, columns):
    return f"""
    User wants: {command}
    Excel has columns: {columns}
    Give Python code to do this using pandas dataframe named df.
    Only return 1 line of code.
    """