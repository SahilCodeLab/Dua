from flask import Flask, request, send_file, render_template
from utils.excel_handler import process_excel
import os

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        file = request.files["excel"]
        command = request.form["command"]
        file.save("uploaded.xlsx")
        output_file = process_excel("uploaded.xlsx", command)
        return send_file(output_file, as_attachment=True)
    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)